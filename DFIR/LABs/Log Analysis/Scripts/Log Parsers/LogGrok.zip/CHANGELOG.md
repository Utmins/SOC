# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-08-15
### Added
- Initial public release of `log_grok_parser.py`
- Auto/preset/builtin pattern selection
- CSV and JSONL output formats
- Example patterns and logs
- GitHub scaffolding: README, LICENSE, CONTRIBUTING, .gitignore, presets