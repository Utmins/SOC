# Changelog

## [0.1.0] - 2025-08-15
### Added
- Initial public release of `utmp_localtime.py` and `utmp_utctime.py`
- Framed table output with ANSI colorized "type"
- Safe width computation that ignores ANSI sequences
- Localtime vs UTC time formatting variants