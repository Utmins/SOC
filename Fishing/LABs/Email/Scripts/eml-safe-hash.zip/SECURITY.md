# Security Policy

## Safe Usage
- Запускайте скрипт в изолированной среде.
