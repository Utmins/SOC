#!/usr/bin/env bash
python3 eml_safe_hash_algo_pw.py examples/sample.eml --algo sha256,md5
